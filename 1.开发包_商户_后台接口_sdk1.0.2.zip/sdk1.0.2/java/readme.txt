﻿UPMP JAVA SDK

2012-10-11

==== 基本要求 ====

    JDK 1.5及以上版本


==== 文件结构 ====

<java sdk>
  │
  ├src┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈类文件夹
  │  │
  │  ├com.unionpay.upmp.sdk.conf
  │  │  │
  │  │  └UpmpConfig.java┈┈┈┈┈┈基础配置类文件
  │  │
  │  ├com.unionpay.upmp.sdk.examples
  │  │  │
  │  │  ├PurchaseExample.java┈┈┈ 订单推送请求接口实例类文件
  │  │  │
  │  │  ├QueryExample.java┈┈┈┈┈交易信息查询接口实例类文件
  │  │  │
  │  │  ├RefundExample.java┈┈┈┈ 退货接口实例类文件
  │  │  │
  │  │  └VoidExample.java┈┈┈┈┈ 消费撤销接口实例类文件
  │  │
  │  ├com.unionpay.upmp.sdk.service
  │  │  │
  │  │  └UpmpService.java┈┈┈┈┈ 接口处理核心类
  │  │
  │  └com.unionpay.upmp.sdk.util
  │      │
  │      ├HttpUtil.java┈┈┈┈┈┈ HttpClient处理类文件
  │      │ 
  │      ├httputil.properties┈┈┈ HttpClient配置文件
  │      │
  │      ├UpmpCore.java┈┈┈┈┈┈ 公用函数类文件
  │      │
  │      └UpmpMd5Encrypt.java┈┈┈ MD5签名类文件
  │
  ├web┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈页面文件夹
  │  │  
  │  ├notify_url.jsp ┈┈┈┈┈┈┈ 异步通知页面
  │  │
  │  ├return_url.jsp ┈┈┈┈┈┈┈ 通知跳转页面
  │  │
  │  └WEB-INF
  │      │
  │      └lib（如果JAVA项目中包含这些jar包，则不需要导入）
  │        │
  │        ├commons-codec-1.5.jar
  │        │
  │        ├commons-httpclient-3.1.jar
  │        │
  │        └commons-logging-1.1.1.jar
  │
  └readme.txt ┈┈┈┈┈┈┈┈┈┈┈使用说明文本


==== 注意事项 ====

    请修改配置文件：src/upmp.properties

    本代码示例中获取远程HTTP信息使用的是commons-httpclient-3.1版本的第三方jar包。
    如果您不想使用该方式实现获取远程HTTP功能，可用其他方式替代，此时需您自行编写代码。

