//
//  main.m
//  UPPayDemoPro
//
//  Created by liwang on 14-3-25.
//  Copyright (c) 2014年 liwang. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UPAppDelegate class]));
    }
}
